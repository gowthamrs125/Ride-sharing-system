package com.rideshare.model;

public enum RideStatus {
    PENDING,
    ONGOING,
    COMPLETED,
    CANCELLED
}
