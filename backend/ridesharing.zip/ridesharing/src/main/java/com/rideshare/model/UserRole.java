package com.rideshare.model;

public enum UserRole {
    USER,
    DRIVER
}
