package com.rideshare.controller;

import com.rideshare.model.User;
import com.rideshare.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public String register(@RequestBody User user) {
        Optional<User> existing = userService.getByPhone(user.getPhone());
        if (existing.isPresent()) {
            return "User already registered with this phone number.";
        }

        userService.registerUser(user);
        return "Registration successful. Please login.";
    }

    @PostMapping("/login")
    public Object login(@RequestParam String loginField, @RequestParam String password) {
        Optional<User> user = userService.login(loginField, password);

        if (user.isPresent()) {
            return user.get();
        } else {
            return "Invalid credentials.";
        }
    }
}
