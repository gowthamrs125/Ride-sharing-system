package com.rideshare.service;

import com.rideshare.model.Ride;
import com.rideshare.repository.RideRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RideService {

    @Autowired
    private RideRepository rideRepo;

    public List<Ride> getAllRides() {
        return rideRepo.findAll();
    }

    public Optional<Ride> getRideById(Long id) {
        return rideRepo.findById(id);
    }

    public Ride createRide(Ride ride) {
        return rideRepo.save(ride);
    }

    public Ride updateRide(Long id, Ride updatedRide) {
        return rideRepo.findById(id).map(ride -> {
            ride.setOrigin(updatedRide.getOrigin());
            ride.setDestination(updatedRide.getDestination());
            ride.setUser(updatedRide.getUser());
            return rideRepo.save(ride);
        }).orElse(null);
    }

    public void deleteRide(Long id) {
        rideRepo.deleteById(id);
    }

    public List<Ride> getRidesByOrigin(String origin) {
        return rideRepo.findByOrigin(origin);
    }

    public List<Ride> getRidesByDestination(String destination) {
        return rideRepo.findByDestination(destination);
    }

    public List<Ride> getRidesByUserId(Long userId) {
        return rideRepo.findByUserId(userId);
    }
}
